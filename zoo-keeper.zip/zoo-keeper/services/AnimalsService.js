const fs = require('fs');
const path = require('path');
const zooDataPath = path.join(__dirname, '../data/zoo.json');

const readData = () => {
    const data = fs.readFileSync(zooDataPath);
    return JSON.parse(data);
};

const writeData = (data) => {
    fs.writeFileSync(zooDataPath, JSON.stringify(data, null, 2));
};

exports.getAllAnimals = () => {
    return readData();
};

exports.getAnimalById = (id) => {
    const animals = readData();
    return animals.find(animal => animal.id === parseInt(id));
};

exports.getEndangeredAnimals = () => {
    const animals = readData();
    return animals.filter(animal => animal.isEndangered);
};

exports.getAnimalsByHabitat = (habitat) => {
    const animals = readData();
    return animals.filter(animal => animal.habitat.toLowerCase() === habitat.toLowerCase());
};

exports.getAnimalsBySpecies = (species) => {
    const animals = readData();
    return animals.filter(animal => animal.species.toLowerCase() === species.toLowerCase());
};

exports.addAnimal = (newAnimal) => {
    const animals = readData();
    newAnimal.id = animals.length ? animals[animals.length - 1].id + 1 : 1;
    animals.push(newAnimal);
    writeData(animals);
    return newAnimal;
};

exports.updateAnimal = (id, updatedAnimal) => {
    const animals = readData();
    const index = animals.findIndex(animal => animal.id === parseInt(id));
    if (index !== -1) {
        animals[index] = { ...animals[index], ...updatedAnimal };
        writeData(animals);
        return animals[index];
    }
    return null;
};

exports.deleteAnimal = (id) => {
    const animals = readData();
    const index = animals.findIndex(animal => animal.id === parseInt(id));
    if (index !== -1) {
        animals.splice(index, 1);
        writeData(animals);
        return true;
    }
    return false;
};
