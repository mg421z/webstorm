const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../data/zoo.json');

function addAnimal(req, res) {
    const newAnimal = req.body;

    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Błąd odczytu pliku.' });
        }

        let animals = [];
        try {
            animals = JSON.parse(data);
        } catch (parseError) {
            return res.status(500).json({ error: 'Błąd parsowania pliku.' });
        }

        const newId = animals.length > 0 ? Math.max(...animals.map(animal => animal.id)) + 1 : 1;
        newAnimal.id = newId;

        animals.push(newAnimal);

        fs.writeFile(dataPath, JSON.stringify(animals, null, 2), 'utf8', (err) => {
            if (err) {
                return res.status(500).json({ error: 'Błąd zapisu do pliku.' });
            }
            res.status(201).json(newAnimal);
        });
    });
}

function getAllAnimals(req, res) {
    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Błąd odczytu pliku.' });
        }
        res.json(JSON.parse(data));
    });
}

function getAnimalById(req, res) {
    const id = parseInt(req.params.id);
    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Błąd odczytu pliku.' });
        }

        let animals = [];
        try {
            animals = JSON.parse(data);
        } catch (parseError) {
            return res.status(500).json({ error: 'Błąd parsowania pliku.' });
        }

        const animal = animals.find(a => a.id === id);
        if (!animal) {
            return res.status(404).json({ error: 'Nie znaleziono zwierzęcia o tym ID.' });
        }

        res.json(animal);
    });
}

function getEndangeredAnimals(req, res) {
    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Błąd odczytu pliku.' });
        }

        let animals = [];
        try {
            animals = JSON.parse(data);
        } catch (parseError) {
            return res.status(500).json({ error: 'Błąd parsowania pliku.' });
        }

        const endangered = animals.filter(a => a.isEndangered);
        res.json(endangered);
    });
}

function getAnimalsByHabitat(req, res) {
    const habitat = req.params.habitat;
    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Błąd odczytu pliku.' });
        }

        let animals = [];
        try {
            animals = JSON.parse(data);
        } catch (parseError) {
            return res.status(500).json({ error: 'Błąd parsowania pliku.' });
        }

        const filtered = animals.filter(a => a.habitat.toLowerCase() === habitat.toLowerCase());
        res.json(filtered);
    });
}

function updateAnimal(req, res) {
    const id = parseInt(req.params.id);
    const updatedAnimal = req.body;

    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Błąd odczytu pliku.' });
        }

        let animals = [];
        try {
            animals = JSON.parse(data);
        } catch (parseError) {
            return res.status(500).json({ error: 'Błąd parsowania pliku.' });
        }

        const animalIndex = animals.findIndex(a => a.id === id);
        if (animalIndex === -1) {
            return res.status(404).json({ error: 'Nie znaleziono zwierzęcia o tym ID.' });
        }

        animals[animalIndex] = { ...animals[animalIndex], ...updatedAnimal };

        fs.writeFile(dataPath, JSON.stringify(animals, null, 2), 'utf8', (err) => {
            if (err) {
                return res.status(500).json({ error: 'Błąd zapisu do pliku.' });
            }
            res.json(animals[animalIndex]);
        });
    });
}

function deleteAnimal(req, res) {
    const id = parseInt(req.params.id);

    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ error: 'Błąd odczytu pliku.' });
        }

        let animals = [];
        try {
            animals = JSON.parse(data);
        } catch (parseError) {
            return res.status(500).json({ error: 'Błąd parsowania pliku.' });
        }

        const animalIndex = animals.findIndex(a => a.id === id);
        if (animalIndex === -1) {
            return res.status(404).json({ error: 'Nie znaleziono zwierzęcia o tym ID.' });
        }

        animals.splice(animalIndex, 1);

        fs.writeFile(dataPath, JSON.stringify(animals, null, 2), 'utf8', (err) => {
            if (err) {
                return res.status(500).json({ error: 'Błąd zapisu do pliku.' });
            }
            res.status(204).send();
        });
    });
}

module.exports = {
    addAnimal,
    getAllAnimals,
    getAnimalById,
    getEndangeredAnimals,
    getAnimalsByHabitat,
    updateAnimal,
    deleteAnimal
};
