const express = require('express');
const bodyParser = require('body-parser');
const animalsController = require('./controllers/AnimalsController');

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.post('/animals', animalsController.addAnimal);
app.get('/animals', animalsController.getAllAnimals);
app.get('/animals/:id', animalsController.getAnimalById);
app.get('/animals/endangered', animalsController.getEndangeredAnimals);
app.get('/animals/habitat/:habitat', animalsController.getAnimalsByHabitat);
app.put('/animals/:id', animalsController.updateAnimal);
app.delete('/animals/:id', animalsController.deleteAnimal);

app.listen(port, () => {
    console.log(`Serwer działa na http://localhost:${port}`);
});
